import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { writeFileSync, mkdirSync, createReadStream, existsSync, statSync } from 'fs';
import { dirname, join, normalize, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

/** En dev: `/finanzas/*` → repo `finanzas/`; `/acceso-finanzas` → `acceso-finanzas.html` en la raíz del repo. */
function serveRepoMarketingStatics() {
  const repoRoot = resolve(__dirname, '..');
  const finRoot = join(repoRoot, 'finanzas');
  return {
    name: 'serve-repo-marketing-statics',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const raw = req.url?.split('?')[0] || '';
        if (raw === '/acceso-finanzas' || raw === '/acceso-finanzas/') {
          const acc = join(repoRoot, 'acceso-finanzas.html');
          if (existsSync(acc)) {
            try {
              if (statSync(acc).isFile()) {
                res.setHeader('Content-Type', 'text/html; charset=utf-8');
                return createReadStream(acc).on('error', () => next()).pipe(res);
              }
            } catch {
              /* fall through */
            }
          }
          return next();
        }
        if (!raw.startsWith('/finanzas')) return next();
        let rel = raw === '/finanzas' || raw === '/finanzas/' ? 'finanzas.html' : raw.slice('/finanzas/'.length);
        if (!rel || rel.includes('..')) return next();
        const fp = resolve(finRoot, normalize(rel));
        if (!fp.startsWith(finRoot) || !existsSync(fp)) return next();
        try {
          if (!statSync(fp).isFile()) return next();
        } catch {
          return next();
        }
        if (fp.endsWith('.html')) res.setHeader('Content-Type', 'text/html; charset=utf-8');
        else if (fp.endsWith('.css')) res.setHeader('Content-Type', 'text/css; charset=utf-8');
        else if (fp.endsWith('.js')) res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
        createReadStream(fp).on('error', () => next()).pipe(res);
      });
    },
  };
}

function authConfigPlugin() {
  return {
    name: 'auth-config',
    closeBundle() {
      const out = join(__dirname, 'dist', 'credito-app', 'auth-config.js');
      mkdirSync(dirname(out), { recursive: true });
      const url = process.env.PUBLIC_SUPABASE_URL || '';
      const key = process.env.PUBLIC_SUPABASE_ANON_KEY || '';
      const storageApi = process.env.PUBLIC_MARKETING_STORAGE_API || '';
      const fallbackOrigin = (process.env.PUBLIC_APP_ORIGIN_FALLBACK || 'https://www.hecom.club').replace(/\/$/, '');
      const knownHostsRaw =
        process.env.PUBLIC_KNOWN_APP_HOSTS ||
        'www.marketingconholistic.com,marketingconholistic.com,www.hecom.club,hecom.club';
      const knownHostsArr = knownHostsRaw
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const knownHostsJson = JSON.stringify(knownHostsArr);
      writeFileSync(
        out,
        `window.__SUPABASE_URL__="${url.replace(/"/g, '\\"')}";window.__SUPABASE_ANON_KEY__="${key.replace(/"/g, '\\"')}";window.__MARKETING_STORAGE_API__="${storageApi.replace(/"/g, '\\"')}";window.__APP_ORIGIN_FALLBACK__="${fallbackOrigin.replace(/"/g, '\\"')}";window.__KNOWN_APP_HOSTS__=${knownHostsJson};\n`,
        'utf8'
      );
    },
  };
}

export default defineConfig({
  plugins: [react(), authConfigPlugin(), serveRepoMarketingStatics()],
  base: '/credito-app/',
  define: {
    'import.meta.env.PUBLIC_SUPABASE_URL': JSON.stringify(process.env.PUBLIC_SUPABASE_URL ?? ''),
    'import.meta.env.PUBLIC_SUPABASE_ANON_KEY': JSON.stringify(process.env.PUBLIC_SUPABASE_ANON_KEY ?? ''),
  },
  build: {
    rollupOptions: {
      output: {
        entryFileNames: 'credito-app.js',
        chunkFileNames: 'credito-app.js',
        assetFileNames: 'credito-app.[ext]',
      },
    },
  },
});
